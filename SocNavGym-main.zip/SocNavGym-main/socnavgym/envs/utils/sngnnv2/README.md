# INFORMATION
This is an adapted version of the SNGNN-v2 code. The original repository can be found [here](https://github.com/gnns4hri/sngnnv2).